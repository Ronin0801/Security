<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_ID'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['record_ID'])) {
    $record_ID = $_GET['record_ID'];
    $user_ID = $_SESSION['user_ID'];

    // Fetch the record to edit
    $sql = "SELECT records.*, categories.category_name 
            FROM records 
            JOIN categories ON records.category_ID = categories.category_ID
            WHERE records.record_ID = ? AND records.user_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $record_ID, $user_ID);
    $stmt->execute();
    $result = $stmt->get_result();
    $record = $result->fetch_assoc();
    $stmt->close();
} else {
    echo "Record ID not specified.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $record_title = $_POST['record_title'];
    $record_username = $_POST['record_username'];
    $record_password = $_POST['record_password'];
    $record_notes = $_POST['record_notes'];

    // Update the record
    $sql = "UPDATE records SET record_title = ?, record_username = ?, record_password = ?, record_notes = ? 
            WHERE record_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $record_title, $record_username, $record_password, $record_notes, $record_ID);

    if ($stmt->execute()) {
        header("Location: records.php?category=" . urlencode($record['category_name']));
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h2>Edit Record</h2>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="record_title" class="form-label">Title:</label>
                        <input type="text" name="record_title" id="record_title" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($record['record_title']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="record_username" class="form-label">Username:</label>
                        <input type="text" name="record_username" id="record_username" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($record['record_username']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="record_password" class="form-label">Password:</label>
                        <input type="password" name="record_password" id="record_password" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($record['record_password']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="record_notes" class="form-label">Notes:</label>
                        <textarea name="record_notes" id="record_notes" 
                                  class="form-control"><?php echo htmlspecialchars($record['record_notes']); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Update Record</button>
                    <a href="records.php?category=<?php echo urlencode($record['category_name']); ?>" 
                       class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
