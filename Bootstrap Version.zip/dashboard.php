<?php
session_start();
if (!isset($_SESSION['user_ID'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header text-center bg-primary text-white">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
            </div>
            <div class="card-body">
                <p class="text-center">Select a category to manage your information:</p>
                <div class="list-group">
                    <a href="records.php?category=Banks" class="list-group-item list-group-item-action">Banks</a>
                    <a href="records.php?category=Emails" class="list-group-item list-group-item-action">Emails</a>
                    <a href="records.php?category=Social Media" class="list-group-item list-group-item-action">Social Media</a>
                    <a href="records.php?category=Entertainment" class="list-group-item list-group-item-action">Entertainment</a>
                    <a href="records.php?category=Others" class="list-group-item list-group-item-action">Others</a>
                </div>
                <div class="mt-4 text-center">
                    <a href="profile_confirm.php" class="btn btn-secondary me-2">My Profile</a>
                    <?php if ($_SESSION['user_type'] == 1): ?>
                        <a href="admin.php" class="btn btn-warning me-2">Admin</a>
                    <?php endif; ?>
                    <a href="logout.php" class="btn btn-danger">Logout</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
