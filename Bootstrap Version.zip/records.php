<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_ID'])) {
    header("Location: login.php");
    exit();
}

$category = $_GET['category']; // Get the category from the URL
$user_ID = $_SESSION['user_ID'];

// Fetch records for the selected category
$sql = "SELECT * FROM records 
        JOIN categories ON records.category_ID = categories.category_ID 
        WHERE user_ID = ? AND category_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $user_ID, $category);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($category); ?> Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleDetails(rowId) {
            const detailsRow = document.getElementById(`details-${rowId}`);
            const revealButton = document.getElementById(`reveal-${rowId}`);
            const hideButton = document.getElementById(`hide-${rowId}`);
            
            if (detailsRow.style.display === "none") {
                detailsRow.style.display = "table-row";
                revealButton.style.display = "none";
                hideButton.style.display = "inline";
            } else {
                detailsRow.style.display = "none";
                revealButton.style.display = "inline";
                hideButton.style.display = "none";
            }
        }
    </script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><?php echo htmlspecialchars($category); ?> Records</h2>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>

        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h3>Add New Record</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="add_record.php">
                    <input type="hidden" name="category" value="<?php echo htmlspecialchars($category); ?>">
                    <div class="mb-3">
                        <label for="record_title" class="form-label">Title:</label>
                        <input type="text" name="record_title" id="record_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="record_username" class="form-label">Username:</label>
                        <input type="text" name="record_username" id="record_username" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="record_password" class="form-label">Password:</label>
                        <input type="password" name="record_password" id="record_password" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="record_notes" class="form-label">Notes:</label>
                        <textarea name="record_notes" id="record_notes" class="form-control"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Record</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-success text-white">
                <h3>Existing Records</h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['record_title']); ?></td>
                                <td>
                                    <button id="reveal-<?php echo $row['record_ID']; ?>" 
                                            class="btn btn-info btn-sm" 
                                            onclick="toggleDetails(<?php echo $row['record_ID']; ?>); return false;">
                                        Reveal
                                    </button>
                                    <button id="hide-<?php echo $row['record_ID']; ?>" 
                                            class="btn btn-warning btn-sm" 
                                            onclick="toggleDetails(<?php echo $row['record_ID']; ?>); return false;" 
                                            style="display: none;">
                                        Hide
                                    </button>
                                    <a href="edit_record.php?record_ID=<?php echo $row['record_ID']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <a href="delete_record.php?record_ID=<?php echo $row['record_ID']; ?>" 
                                       class="btn btn-danger btn-sm" 
                                       onclick="return confirm('Are you sure you want to delete this record?');">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                            <tr id="details-<?php echo $row['record_ID']; ?>" style="display: none;">
                                <td colspan="2">
                                    <strong>Username:</strong> <?php echo htmlspecialchars($row['record_username']); ?><br>
                                    <strong>Password:</strong> <?php echo htmlspecialchars($row['record_password']); ?><br>
                                    <strong>Notes:</strong> <?php echo htmlspecialchars($row['record_notes']); ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

<?php
$stmt->close();
?>
