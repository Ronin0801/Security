<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_name = $_POST['user_name'];
    $user_email = $_POST['user_email'];
    $user_pass = $_POST['user_pass'];

    // Validate password
    if (strlen($user_pass) < 8 || !preg_match('/\d/', $user_pass)) {
        $error_message = "Password must be at least 8 characters long and contain at least one number.";
    } else {
        $hashed_pass = password_hash($user_pass, PASSWORD_DEFAULT); // Hash password

        // Check if username or email already exists
        $check_sql = "SELECT * FROM users WHERE user_name = ? OR user_email = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("ss", $user_name, $user_email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error_message = "Username or email already exists. Please choose a different one.";
        } else {
            // Insert new user
            $sql = "INSERT INTO users (user_name, user_email, user_pass, user_type) VALUES (?, ?, ?, 0)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $user_name, $user_email, $hashed_pass);

            if ($stmt->execute()) {
                $success_message = "Registration successful!";
            } else {
                $error_message = "Error: " . $stmt->error;
            }
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header text-center bg-primary text-white">
                        <h2>Register</h2>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error_message)): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                        <?php endif; ?>
                        <?php if (isset($success_message)): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo $success_message; ?>
                            </div>
                        <?php endif; ?>
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="user_name" class="form-label">Username</label>
                                <input type="text" id="user_name" name="user_name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="user_email" class="form-label">Email</label>
                                <input type="email" id="user_email" name="user_email" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="user_pass" class="form-label">Password</label>
                                <input type="password" id="user_pass" name="user_pass" class="form-control" required>
                                <small class="text-muted">Password must be at least 8 characters long and contain at least one number.</small>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Register</button>
                        </form>
                        <div class="text-center mt-3">
                            <p>Already have an account?</p>
                            <a href="login.php" class="btn btn-secondary">Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
