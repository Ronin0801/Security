<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_ID'])) {
    header("Location: login.php");
    exit();
}

$user_ID = $_SESSION['user_ID'];

// Fetch current user information
$sql = "SELECT * FROM users WHERE user_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_ID);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_user_name = $_POST['user_name'];
    $new_user_email = $_POST['user_email'];
    $new_user_pass = $_POST['user_pass'];

    // Validate password (if provided)
    if (!empty($new_user_pass)) {
        if (strlen($new_user_pass) < 8) {
            $error = "Password must be at least 8 characters long.";
        } elseif (!preg_match("/\d/", $new_user_pass)) {
            $error = "Password must contain at least one number.";
        }
    }

    if (empty($error)) {
        // Update the user profile (username and email)
        $sql = "UPDATE users SET user_name = ?, user_email = ? WHERE user_ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $new_user_name, $new_user_email, $user_ID);

        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Profile updated successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }

        // If the user wants to update their password, hash the new password and update it
        if (!empty($new_user_pass)) {
            $hashed_password = password_hash($new_user_pass, PASSWORD_DEFAULT);

            $sql = "UPDATE users SET user_pass = ? WHERE user_ID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $hashed_password, $user_ID);

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Password updated successfully!</div>";
            } else {
                echo "<div class='alert alert-danger'>Error updating password: " . $stmt->error . "</div>";
            }
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h2>Update Your Profile</h2>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger text-center" role="alert">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="user_name" class="form-label">Username:</label>
                                <input type="text" name="user_name" id="user_name" 
                                    class="form-control" value="<?php echo htmlspecialchars($user['user_name']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="user_email" class="form-label">Email:</label>
                                <input type="email" name="user_email" id="user_email" 
                                    class="form-control" value="<?php echo htmlspecialchars($user['user_email']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="user_pass" class="form-label">New Password (leave empty to keep current password):</label>
                                <input type="password" name="user_pass" id="user_pass" class="form-control">
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Update Profile</button>
                            </div>
                        </form>

                        <div class="text-center mt-3">
                            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
