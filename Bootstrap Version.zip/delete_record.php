<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_ID'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['record_ID'])) {
    $record_ID = $_GET['record_ID'];
    $user_ID = $_SESSION['user_ID'];

    // Delete the record from the database
    $sql = "DELETE FROM records WHERE record_ID = ? AND user_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $record_ID, $user_ID);

    if ($stmt->execute()) {
        // After deleting, redirect back to the records page for the specific category
        header("Location: dashboard.php");
        exit();  // Ensure no further code is executed
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Record ID not specified.";
}
?>